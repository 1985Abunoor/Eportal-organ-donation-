<!-- ======= Hero Section ======= -->
<section id="hero" class="d-flex align-items-center">
  <div class="container">
    <h1>Oman Organs Donation</h1>
    <h2>Helping each other, saving lives</h2>
    <br>
  </div>
</section><!-- End Hero -->
<!-- ======= Appointment Section ======= -->
<section id="appointment" class="appointment section-bg pb-5">
    <div class="container">
        <div class="section-title">
            <h2>Thank You</h2>
            <p>Thank you, we'll get in touch you you as soon as possible, stay tuned.</p>
        </div>

    </div>
</section>
