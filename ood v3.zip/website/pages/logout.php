<?php
    session_destroy();

    header("Location: ?p=home");
?>