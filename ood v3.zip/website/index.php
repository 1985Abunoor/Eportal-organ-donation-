<?php
session_start();
error_reporting(0);

// get the page name from url link
$page = htmlspecialchars($_GET['p']);

// include header
include_once('database.php');
include_once('pages/forms.php');
include_once('pages/header.php');

// if the page is not foud to be included will fallback to home page
if(!@include('pages/'.$page.'.php')){
    include('pages/home.php');
}

// include the footer
include_once('pages/footer.php');

?>
