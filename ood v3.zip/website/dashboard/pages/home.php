<section id="hero" class="d-flex align-items-center">
<div class="container">
    <h1>Oman Organs Donation</h1>
    <h2>Helping each other, saving lives</h2>
</div>
</section>

<section id="appointment" class="appointment section-bg pb-5">
    <div class="container">
        <div class="section-title">
            <h2><span style="text-transform: capitalize;"><?php echo $_SESSION['user_name']; ?></span> Dashboard</h2>
            <p>Welcome to dashboard, here you can manage doctors profiles, patients and donors applications.</p>
        </div>
</section>