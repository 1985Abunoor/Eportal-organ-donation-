<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Organs Donation - Dashboard</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="../../assets/img/favicon.png" rel="icon">
  <link href="../../assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="../../assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
  <link href="../../assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="../../assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="../../assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="../../assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="../../assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="../../assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="../../assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Main CSS File -->
  <link href="../../assets/css/style.css" rel="stylesheet">

</head>
<body class="appointment section-bg pb-5">
  <div class="container mt-5 pt-5">
    <div class="section-title">
      <h2>Oman Organs Donation - Dashboard</h2>
      <p>Login to your account</p>
    </div>

    <form method="post" role="form" class="php-email-form">
      <div class="col-6 mx-auto">
        <div class="col-12 form-group">
          <input type="text" name="username" class="form-control" id="name" placeholder="Username" reuired>
        </div>
        <div class="col-12 form-group">
          <input type="password" name="password" class="form-control" id="name" placeholder="Password">
        </div>
      <div class="mb-3">
        <div class="error-message"></div>
      </div>
      <div class="text-center"><button name="login" type="submit">Login</button></div>
    </form>
 
  </div>
</body>
</html>