<section class="appointment section-bg pb-5 mt-5">
    <div class="container">
        <div class="section-title">
            <h2>Patient Applications Details</h2>
        </div>
        <table class="table col-6">
        <?php
            $q = htmlspecialchars($_GET['q']);
            
            $sql = "SELECT * FROM patients WHERE id = '$q'";

            $result = $db->query($sql);
            if($result->num_rows != 0):
                while($row = $result->fetch_assoc()):
                    $doctor = $row['doctor_referred_id'];
                    $origin_needed = $row['origin_needed'];
                    $doctor_referred_id = $row['doctor_referred_id'];
                    
        ?>
            <tr>
                <td class="col-4">Name</td>
                <td class="col-6"><?php echo $row['name']; ?></td>
            </tr>
            <tr>
                <td class="col-4">Contact No:</td>
                <td><?php echo $row['contact_no']; ?></td>
            </tr>
            <tr>
                <td class="col-4">Birthdate:</td>
                <td><?php echo $row['birthdate']; ?></td>
            </tr>
            <tr>
                <td class="col-4">Id Card:</td>
                <td><?php echo $row['id_card']; ?></td>
            </tr>
            <tr>
                <td class="col-4">Governate:</td>
                <td><?php echo $row['governate']; ?></td>
            </tr>
            <tr>
                <td class="col-4">Address:</td>
                <td><?php echo $row['address']; ?></td>
            </tr>
            <tr>
                <td class="col-4">Health:</td>
                <td><?php echo $row['health']; ?></td>
            </tr>
            <tr>
                <td class="col-4">Emergency Contact</td>
                <td><?php echo $row['emergency_contact_name']; ?></td>
            </tr>
            <tr>
                <td class="col-4">Emergency Contact No</td>
                <td><?php echo $row['emergency_contact_no']; ?></td>
            </tr>
            <tr>
                <td class="col-4">Emergency Contact E-mail</td>
                <td><?php echo $row['emergency_contact_email']; ?></td>
            </tr>
            <tr>
                <td class="col-4">Blood Type</td>
                <td class="col-6"><?php echo $row['blood_type']; ?></td>
            </tr>
            <tr>
                <td class="col-4">Origin Needed</td>
                <td class="col-6"><?php echo $row['origin_needed']; ?></td>
            </tr>
        <?php
                endwhile;
            endif;
        ?>
        </table>

        <div class="p-3">
            <h4>Donors</h4>
            <hr>

            <form method="post" class="d-flex" onsubmit="return confirm('Are you sure you want to assign this donor?')">
            <div class="col-6 form-group mt-3 mt-md-0 mr-3">
            <select name="item" id="item" class="form-select">
                <option value="">Select Donor</option>
            <?php
                $sql = "SELECT * FROM donors WHERE origin_to_donate = '$origin_needed' OR origin_to_donate = 'all' AND patient_id IS NULL ORDER BY id DESC";

                $result = $db->query($sql);
                if($result->num_rows != 0):
                    while($row = $result->fetch_assoc()):
            ?>
                    <option value="<?php echo $row['id']; ?>">
                        <?php echo $row['name']; ?>
                    </option>
            <?php
                    endwhile;
                endif;
            ?>
            </select>
            </div>
            <button class="btn btn-sm btn-info" name="assign-donor">
                <i class="fa fa-user-plus"></i> Assign
            </button>
            <input type="hidden" name="patient_id" value="<?php echo $q; ?>" />
            </form>
            
            <h5 class="mt-5 mb-5">Donor Details:</h5>
            <?php
                $sql = "SELECT * FROM donors WHERE patient_id = '$q'";

                $result = $db->query($sql);
                if($result->num_rows != 0):
                    while($row = $result->fetch_assoc()):
            ?>
                <table class="table col-6">
                    <tr>
                        <td class="col-4">Name:</td>
                        <td><?php echo $row['name']; ?></td>
                    </tr>
                    <tr>
                        <td class="col-4">Contact No:</td>
                        <td><?php echo $row['contact_no']; ?></td>
                    </tr>
                    <tr>
                        <td class="col-4">Birthdate:</td>
                        <td><?php echo $row['birthdate']; ?></td>
                    </tr>
                    <tr>
                        <td class="col-4">Id Card:</td>
                        <td><?php echo $row['id_card']; ?></td>
                    </tr>
                    <tr>
                        <td class="col-4">Governate:</td>
                        <td><?php echo $row['governate']; ?></td>
                    </tr>
                    <tr>
                        <td class="col-4">Address:</td>
                        <td><?php echo $row['address']; ?></td>
                    </tr>
                    <tr>
                        <td class="col-4">Health:</td>
                        <td><?php echo $row['health']; ?></td>
                    </tr>
                    <tr>
                        <td class="col-4">Emergency Contact</td>
                        <td><?php echo $row['emergency_contact_name']; ?></td>
                    </tr>
                    <tr>
                        <td class="col-4">Emergency Contact No</td>
                        <td><?php echo $row['emergency_contact_no']; ?></td>
                    </tr>
                    <tr>
                        <td class="col-4">Emergency Contact E-mail</td>
                        <td><?php echo $row['emergency_contact_email']; ?></td>
                    </tr>
                    <tr>
                        <td class="col-4">Origin to donate</td>
                        <td class="col-6"><?php echo $row['origin_to_donate']; ?></td>
                    </tr>
                    <tr>
                        <td class="col-4">Blood Type</td>
                        <td class="col-6"><?php echo $row['blood_type']; ?></td>
                    </tr>
                </table>
            <?php
                    endwhile;
                endif;
            ?>

        </div>


        <div class="p-3">
            <h4>Doctors</h4>
            <hr>

            <form method="post" class="d-flex" onsubmit="return confirm('Are you sure you want to assign this doctor?')">
            <input type="hidden" name="patient_id" value="<?php echo $q; ?>" />
            <div class="col-6 form-group mt-3 mt-md-0 mr-3">
                <select name="item" id="item" class="form-select">
                    <option value="">Select a Doctor</option>
                    <?php
                        $sql = "SELECT * FROM doctors WHERE id != '$doctor_referred_id' ORDER BY id DESC";

                        $result = $db->query($sql);
                        if($result->num_rows != 0):
                            while($row = $result->fetch_assoc()):
                    ?>
                            <option value="<?php echo $row['id']; ?>">
                                <?php echo $row['name']; ?>
                            </option>
                    <?php
                            endwhile;
                        endif;
                    ?>
                </select>
            </div>
            <button class="btn btn-sm btn-info" name="assign-doctor">
                <i class="fa fa-user-plus"></i> Assign
            </button>
            </form>
            
            <h5 class="mt-5 mb-5">Doctor Details:</h5>
            <?php
                $sql = "SELECT * FROM doctors WHERE id = '$doctor_referred_id'";

                $result = $db->query($sql);
                if($result->num_rows != 0):
                    while($row = $result->fetch_assoc()):
            ?>
                <table class="table col-6">
                    <tr>
                        <td class="col-4">Name:</td>
                        <td><?php echo $row['name']; ?></td>
                    </tr>
                    <tr>
                        <td class="col-4">Contact No:</td>
                        <td><?php echo $row['contact_no']; ?></td>
                    </tr>
                    <tr>
                        <td class="col-4">Specialty</td>
                        <td><?php echo $row['specialty']; ?></td>
                    </tr>
                    <tr>
                        <td class="col-4">About</td>
                        <td class="col-6"><?php echo $row['about']; ?></td>
                    </tr>
                </table>
            <?php
                    endwhile;
                endif;
            ?>

        </div>
    </div>
</section>