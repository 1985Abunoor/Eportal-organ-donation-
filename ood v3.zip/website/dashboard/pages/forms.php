<?php
if(isset($_POST['login'])){
    $username = mysqli_real_escape_string($db, htmlspecialchars($_POST['username']));
    $password = mysqli_real_escape_string($db, htmlspecialchars($_POST['password']));

    $sql = "SELECT * FROM users WHERE username = '$username'";

    $result = $db->query($sql);

    if($result->num_rows != 0){
        while($row = $result->fetch_assoc()){
            $pass = $row['password'];
            $uid = $row['id'];
            $uname = $row['username'];
            $utype = $row['user_type'];
        }

        if(password_verify($password, $pass) == true){
            $_SESSION['user_id'] = $uid;
            $_SESSION['user_name'] = $uname;
            $_SESSION['user_type'] = $utype;
            
            if(empty(htmlspecialchars($_GET['ref']))){
                header("Location: ?p=home");
            } else {
                header("Location: ?p=".$_GET['ref']);
            }
        } else {
            echo "<div class='text-white bg-danger col-12'>Username or password are in correct.</div>";
        }
    } else {
        echo "<div class='text-white bg-danger col-12'>Username or password are in correct.</div>";
    }

}

if(isset($_POST['delete-doctors'])){
    $item = mysqli_real_escape_string($db, htmlspecialchars($_POST['item']));

    $sql = "DELETE FROM doctors WHERE id = '$item'";

    if($db->query($sql) == false){
        echo "<div class='text-white bg-danger col-12'>Something went wrong..</div>";
    }
}

if(isset($_POST['delete-patients'])){
    $item = mysqli_real_escape_string($db, htmlspecialchars($_POST['item']));

    $sql = "DELETE FROM patients WHERE id = '$item'";

    if($db->query($sql) == false){
        echo "<div class='text-white bg-danger col-12'>Something went wrong..</div>";
    }
}

if(isset($_POST['delete-donors'])){
    $item = mysqli_real_escape_string($db, htmlspecialchars($_POST['item']));

    $sql = "DELETE FROM donors WHERE id = '$item'";

    if($db->query($sql) == false){
        echo "<div class='text-white bg-danger col-12'>Something went wrong..</div>";
    }
}

if(isset($_POST['new_doctor'])){
    $name = mysqli_real_escape_string($db, htmlspecialchars($_POST['name']));
    $contact_no = mysqli_real_escape_string($db, htmlspecialchars($_POST['contact_no']));
    $specialty = mysqli_real_escape_string($db, htmlspecialchars($_POST['specialty']));
    $about = mysqli_real_escape_string($db, htmlspecialchars($_POST['about']));

    $sql = "INSERT INTO doctors(name, contact_no, specialty, about) VALUES('$name', '$contact_no', '$specialty', '$about')";

    if($db->query($sql) == true){
        header("Location: ?p=doctors");
    } else {
        echo "<div class='text-white bg-danger col-12'>Something went wrong.</div>";
    }

}

if(isset($_POST['assign-donor'])){
    $item = mysqli_real_escape_string($db, htmlspecialchars($_POST['item']));
    $patient_id = mysqli_real_escape_string($db, htmlspecialchars($_POST['patient_id']));

    $sql = "UPDATE donors SET patient_id = '$patient_id' WHERE id = '$item'";

    if($db->query($sql) == false){
        echo "<div class='text-white bg-danger col-12'>Something went wrong..";
    }
}

if(isset($_POST['assign-doctor'])){
    $item = mysqli_real_escape_string($db, htmlspecialchars($_POST['item']));
    $patient_id = mysqli_real_escape_string($db, htmlspecialchars($_POST['patient_id']));

    $sql = "UPDATE patients SET doctor_referred_id = '$item' WHERE id = '$patient_id'";

    if($db->query($sql) == false){
        echo "<div class='text-white bg-danger col-12'>Something went wrong..</div>";
    }
}
?>