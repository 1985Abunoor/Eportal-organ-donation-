<?php
session_start();
error_reporting(0);

// get the page name from url link
$page = htmlspecialchars($_GET['p']);
$q = htmlspecialchars($_GET['q']);

// include the header
include_once('../database.php');
include_once('pages/forms.php');

// check if user is logged in user and is admin
if(empty($_SESSION['user_type']) || $_SESSION['user_type'] != 'admin'){
    include('pages/login.php');
    exit();
}

include_once('pages/header.php');

// if the page is not foud to be included will fallback to home page
if(!@include('pages/'.$page.'.php')){
    include('pages/home.php');
}

// include the footer
include_once('pages/footer.php');

?>